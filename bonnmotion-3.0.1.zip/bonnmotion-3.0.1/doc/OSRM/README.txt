See README.pdf in doc folder for instructions
